import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Cart } from '../shared/models/Cart';
import { CartItem } from '../shared/models/CartItem';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartSubject = new BehaviorSubject<Cart>({ items: [], totalCount: 0, totalPrice: 0 });

  constructor() {
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
      this.cartSubject.next(JSON.parse(storedCart));
    }
  }

  getCartObservable() {
    return this.cartSubject.asObservable();
  }

  addToCart(food: any) { // Adjust the type according to your Food model
    const currentCart = this.cartSubject.getValue();
    const existingCartItem = currentCart.items.find(item => item.food.id === food.id); // Assuming food.id is unique

    if (existingCartItem) {
      existingCartItem.quantity += 1; // Increase quantity if item already exists
    } else {
      const newCartItem: CartItem = {
        food: food,
        quantity: 1,
        price: food.price // Include the price from the food object
      };
      currentCart.items.push(newCartItem); // Add new item if it doesn't exist
    }

    this.updateCart(currentCart.items);
  }

  removeFromCart(foodId: number | string) {
    const currentCart = this.cartSubject.getValue();
    const updatedItems = currentCart.items.filter(item => item.food.id !== String(foodId));
    this.updateCart(updatedItems);
  }

  changeQuantity(foodId: number | string, quantity: number) {
    const currentCart = this.cartSubject.getValue();
    const updatedItems = currentCart.items.map(item => {
      if (item.food.id === String(foodId)) {
        item.quantity = quantity;
      }
      return item;
    });
    this.updateCart(updatedItems);
  }

  clearCart() {
    this.cartSubject.next({ items: [], totalCount: 0, totalPrice: 0 });
    localStorage.removeItem('cart');
  }

  private updateCart(items: CartItem[]) {
    const totalCount = items.reduce((count, item) => count + item.quantity, 0);
    const totalPrice = items.reduce((total, item) => total + (item.price * item.quantity), 0);
    
    const updatedCart = { items, totalCount, totalPrice };
    this.cartSubject.next(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  }
}
